/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase06;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //Tabla de verdad
        //Es una representación lógica de resultados
        /*
        A   |   B   |   AND |   OR
        V   |   V   |   V   |   V
        V   |   F   |   F   |   V
        F   |   V   |   F   |   V
        F   |   F   |   F   |   F
        
        Negación (NOT)
        A   NOT
        V   F
        F   V        
         */
        //Operadores lógicos
        /*
        & AND (y lógico)
        | OR (o lógico)
        ! NOT (negación)
        Los operandos son booleanos.
        El resultado es booleano.
         */
        boolean log1 = true;
        boolean log2 = false;

        System.out.println("AND &&:");
        System.out.println(log1 && log2); //false

        System.out.println("OR ||:");
        System.out.println(log1 || log2); //true

        System.out.println("NOT !");
        System.out.println(!log1); //false
        System.out.println(!log2); //true

        //Con un solo operador evalúa todas las condiciones
        //Con dos operadores, si la primera condición
        //determina el valor de verdad, ya no evalúa las siguientes
        int n1 = 5;
        int n2 = 10;
        int n3 = 20;

        System.out.println("1_");

        System.out.print("a-");
        System.out.println(" " + (n1 + n2));

        System.out.print("b-");
        System.out.println(" " + (n3 - n1));

        System.out.print("c-");
        System.out.println(" " + n1 * n3);

        System.out.print("d-");
        System.out.println(" " + n3 / n2);

        n1 = 10;
        n2 = 20;
        n3 = 30;
        System.out.println("2_");

        System.out.print("a-");
        System.out.println(" "+(n1 + n2 + n3));

        System.out.print("b-");
        System.out.println(" "+(n1 + n2 + n3) / 3);

        System.out.print("c-");
        System.out.println(" "+(n2 % n1));

        n1 = 5;
        n2 = 10;
        System.out.println("3-");
        System.out.println("n1 es igual" + " " + n1 + "," + " "
                            + "n2 es igual a" + " " + n2 + " " 
                            +"y"+" "+"n1 mas n2 es igual a"+" "+(n1+n2));
        
        
        final double IVA= 1.21;
        double remera= 59.90;
        double pantalon= 99.90;
        double campera= 149.90; 
        
        
        System.out.println("4_");
        
        System.out.print("a-");
        System.out.println("total del iva de la remera:"+" "+(IVA*remera));
        
        System.out.print("b-");
        System.out.println("total del iva del pantalon:"+" "+(IVA*pantalon));
        
        System.out.print("c-");
        System.out.println("total del iva de la campera "+" "+(IVA*campera));
       
    }

}
